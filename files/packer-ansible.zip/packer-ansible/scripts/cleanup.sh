#!/bin/sh

echo 'Cleaning up all leftovers.'