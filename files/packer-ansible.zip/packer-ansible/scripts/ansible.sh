#!/bin/sh

sudo dnf install ansible -y