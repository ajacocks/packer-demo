#!/bin/sh

dnf install ansible -y