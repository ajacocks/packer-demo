#!/bin/sh

sudo dnf install ansible-core -y
ansible-galaxy collection install ansible.posix